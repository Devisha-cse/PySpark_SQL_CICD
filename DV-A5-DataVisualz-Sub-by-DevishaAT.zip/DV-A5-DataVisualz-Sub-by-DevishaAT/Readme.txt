/* Author: Dr. Devisha Arunadevi Tiwari */

AdventureWorksLT2019.bak is the output file of visualization made in PowerBI as part of this assignment.
output_adventurew_lookup is the pdf of output of the given assignment number 5 of data visualization.
