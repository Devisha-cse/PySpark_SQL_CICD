# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 16:59:46 2025

@author: 91983
"""

import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Load the dataset (Correcting the path for Excel file)
df = pd.read_excel(r'C:\Users\91983\OneDrive\Documents\StudentSurvey.xlsx')

# Convert columns to appropriate types (ensure 'Total Amount of Purchases' is numeric, and 'Store setting' is categorical)
df['Total Amount of Purchases'] = pd.to_numeric(df['Total Amount of Purchases'], errors='coerce')
df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
df['Store Setting'] = df['Store Setting'].astype('category')

# Create color format based on 'Total Amount of Purchases' (TAP)
df['TAP_Color'] = df['Total Amount of Purchases'].apply(lambda x: 'red' if 0 < x < 35000 
                                                       else 'yellow' if 35000 <= x < 60000 
                                                       else 'blue' if x >= 60000 else 'gray')

# Initialize the Dash app
app = dash.Dash(__name__)

# Tabular Visualization - Format the total amount of purchase (TAP) based on ‘Store Location’ and ‘Store Setting’
tabular_table = html.Div([
    html.H3('Tabular Visualization - Total Amount of Purchase (TAP)'),
    dcc.Graph(
        id='tabular-visualization',
        figure=px.bar(df, x='Store Location', y='Total Amount of Purchases', color='TAP_Color', 
                      title="Total Amount of Purchase (TAP) by Store Location and Setting")
    ),
])

# Matrix Visualization - Amount spent on Outdoor Sports across different ages and ‘Store Setting’
matrix_table = html.Div([
    html.H3('Matrix Visualization - Amount Spent on Outdoor Sports'),
    dcc.Graph(
        id='matrix-visualization',
        figure=px.density_heatmap(df, x='Age', y='Store Setting', z='OutDoor SportKits', 
                                  color_continuous_scale='Viridis', title="Amount Spent on Outdoor Sports")
    ),
])

# Funnel Chart - Total Amount of Purchase by ‘Store Setting’
funnel_chart = html.Div([
    html.H3('Funnel Chart - Total Amount of Purchase by Store Setting'),
    dcc.Graph(
        id='funnel-chart',
        figure=go.Figure(go.Funnel(
            y=df['Store Setting'].unique(),
            x=df.groupby('Store Setting')['Total Amount of Purchases'].sum().values,
            textinfo="value+percent initial"
        ))
    ),
])

# Pie Chart - Total amount of purchase by different ‘Store Location’ for Suburban ‘Store Setting’
pie_chart = html.Div([
    html.H3('Pie Chart - Total Amount of Purchase by Store Location for Suburban'),
    dcc.Graph(
        id='pie-chart',
        figure=px.pie(df[df['Store Setting'] == 'Suburban'], names='Store Location', 
                      values='Total Amount of Purchases', title="Total Amount of Purchase by Store Location (Suburban)")
    ),
])

# Scatter Plot - Video games purchase and Outdoor sports spent across different ages
scatter_plot = html.Div([
    html.H3('Scatter Plot - Video Games Purchase vs Outdoor Sports Spent by Age'),
    dcc.Graph(
        id='scatter-plot',
        figure=px.scatter(df, x='VideoGames', y='OutDoor SportKits', color='Age', 
                          title="Video Games vs Outdoor Sports Spent by Age")
    ),
])

# Sand Dance Plot - Indoor Sports and Video games spent across different age groups
sand_dance_plot = html.Div([
    html.H3('Sand Dance Plot - Indoor Sports vs Video Games by Age'),
    dcc.Graph(
        id='sand-dance-plot',
        figure=px.scatter(df, x='InDoor SportKits', y='VideoGames', color='Age', 
                          title="Indoor Sports vs Video Games by Age")
    ),
])

# Master Dashboard Layout
app.layout = html.Div([
    tabular_table,
    matrix_table,
    funnel_chart,
    pie_chart,
    scatter_plot,
    sand_dance_plot
])

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
