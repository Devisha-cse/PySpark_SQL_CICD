/* Author: Dr. Devisha Arunadevi Tiwari */

The code is deployed in fully executable form at http://127.0.0.1:8050/

It is PyDash dashboard coded in PyDash with some functionalities from PowerBI.

Tabular Visualization - Total Amount of Purchase (TAP)