/* Author : Dr. Devisha Arunadevi Tiwari */

ExtractedFile-Shaping-and-Combining-Data.xlsx is the output file obtained after solving the assignment.